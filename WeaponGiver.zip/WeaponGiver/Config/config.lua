Config = {}

Config.Notification = 'ESX' -- * CodeM (CodeM M Notification) / ESX (Default)