fx_version 'adamant'
game 'gta5'
lua54 'yes'

author 'uzemvezeto'
description 'Simple script to give weapons to your self.'

client_scripts {
    'Sources/client.lua',
    'Config/config.lua'
}

shared_script '@es_extended/imports.lua'

escrow_ignore 'Config/config.lua'