ESX = exports["es_extended"]:getSharedObject()

RegisterCommand("weapon", function(source, args, rawCommand)
    local weapon = args[1]
    local ammo = tonumber(args[2]) or 500 

    if not weapon then
        if Config.Notification == 'CodeM' then
            TriggerEvent('codem-notification:Create', 'Nem adtál meg fegyver lehívót', 'info', 'Fegyver lekérő', 5000)
        elseif Config.Notification == 'ESX' then
            ESX.ShowNotification('Nem adtál meg fegyver lehívót')
        end
        return  
    end

    GiveWeaponToPed(PlayerPedId(), GetHashKey(weapon), ammo, false, true)
end, false)
